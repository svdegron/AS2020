// main.js
// 
var pj = require('./package.json');
moment.locale('ru');
console.log('start');
// 
$(document).ready(function () {
 var dateStart = new Date();
 addLog(false, moment(dateStart).format('LL') + ' ' + moment(dateStart).format('dddd'));
 addLog(false, "Версия программы " + pj.version);
    loadMyScripts();
});

// var async = require('async');
// var iLine = 0;
// var logToday = undefined;
// // var urlLoadList = 'http://ls3.lan.zlatmash.ru:8080/json/urls.json';
// var urlLoadList = 'http://ls3.lan.zlatmash.ru:8080/json/hot_update.json';
// var getRequest = new XMLHttpRequest();
// var mainWindow = nw.Window.get();
// var scriptCount = 0;
// var mainScriptCount = 0;

// getRequest.onreadystatechange = getFiles;

// function jsonCheckAndParse(str) {
// 	var jsonObject = undefined;
// 	try { jsonObject = JSON.parse(str); }
// 	catch (e) { return undefined; }
// 	return jsonObject;
// } // Формат даты в логах
// function addDate(myDate) {
// 	// 
// 	return moment(myDate).format('HH:mm:ss.SSS');
// } // Вывод логов
// function addLog(showAlert, myLog, myObjects, myColor) {
// 	if(showAlert){ alert(myLog); }
// 	if(myObjects === undefined){ console.log(myLog); }
// 	else { console.log(myLog, Object.keys(myObjects), myObjects);}
// 	var dateLog = new Date();
// 	var idLine = '#line_' + (++iLine);
// 	var myLine = '<div id="line_' + iLine + '">' + addDate(dateLog) + ':&nbsp;' + myLog + '</div>';
// 	$(myLine).appendTo('#logs'); // $('#logs').append(myLine);
// 	if(myColor === undefined){
// 		if(iLine % 2 == 0) { $(idLine).addClass('darkLine'); }
// 		else { $(idLine).addClass('lightLine'); }	
// 	} else { $(idLine).attr( "color", myColor ); }
// } // get-запрос для получения файла urlLoadList
// function getFiles() {
// 	if (getRequest.readyState != 4) return;
// 	if (getRequest.status != 200) { 
// 		addLog(false, 'Нет соединения');
// 		setTimeout(loadMyScripts, 6 * 1000);
// 	} else {
// 		// addLog(false, getRequest.responseText);
// 		var urls = jsonCheckAndParse(getRequest.responseText);
// 		// addLog(false, "main.js - 48 " + urls, urls);
// 		if(urls === undefined){
// 			addLog(false, "Ошибка списка. cNotice v" + pj.version + ". Позвоните по телефону 125");
// 			setTimeout(loadMyScripts, 5 * 60 * 1000);
// 		} else {
// 			addLog(false, 'Проверяем список файлов');
// 			async.forEachOfSeries(urls, function (value, key, callback) {
// 				if(key == "typeObject"){ delete urls[key]; callback(); } //addLog(false, 'найден'); }
// 				else {
// 					addLog(false, "Грузим файл номер - " + (++mainScriptCount)); 
// 					$.getScript(value)
// 					.done(function( script, textStatus ) { 
// 						addLog(false, 'Скрипт загружен - main.js .done ');
// 						delete urls[key]; 
// 						callback(); 
// 					})
// 					.fail(function( jqxhr, settings, exception ) { 
// 						addLog(false, 'Ошибка загрузки скрипта - main.js .fail '); 
// 						callback(exception); 
// 					});
// 				}
// 			}, function (err) {
// 				if(err){
// 					addLog(false, err + ". Ошибка загрузки скриптов. cNotice v" + pj.version + ". Позвоните по телефону 125");
// 					setTimeout(loadMyScripts, 5 * 60 * 1000);
// 				}
// 				else { addLog(false, 'Все файлы на месте'); }
// 			});		
// 		}
// 	}
// } // Проверка соединения и наличия файла
// function loadMyScripts() {
// 	$.ajax({
// 		url: urlLoadList,
// 		type: 'HEAD',
// 		error: function(){ 
// 				addLog(false, 'Отсутствует соединение или файл');
// 				setTimeout(loadMyScripts, 6 * 1000);
// 			}
// 		, success: function(){
// 				addLog(false, 'Соединение установлено, файл найден');
// 				getRequest.open('GET', urlLoadList, true);
// 				getRequest.send();
// 			}
// 		}
// 	);
// 	addLog(false, 'Проверяем соединение и наличие файла ' + urlLoadList);
// } 
// // Когда страница загрузилась запускаем обновлятор
// $(document).ready(function () {
// 	var dateStart = new Date();
// 	addLog(false, moment(dateStart).format('LL') + ' ' + moment(dateStart).format('dddd'));
// 	addLog(false, "Версия программы " + pj.version);
//     loadMyScripts();
// });