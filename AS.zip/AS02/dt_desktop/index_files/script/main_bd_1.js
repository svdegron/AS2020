// main_bd.js
// 
// модуль подключения к базе данных Postgresql
const {Client} = require('pg');
// дванные для подключения
const db = new Client({
  user    : 'postgres',
  host    : 'localhost',
  database: 'kas_DRON_TAXI',
  password: 'pGs12D3t2wX64',
  port    : 5432
  });
// подключение к базе
// запрос - вывести всех пользователей
function selectAllUsers() {
  db.connect();
  db.query('select * from users;', (err, data) => {
    if (err) throw new Error(err);
    console.log(data, err);
    console.log(data.command);
    console.log(data.rows);
    data.rows.forEach( (element, index) => {
      // console.log(index, element);
      for(var key in element) {
        console.log(index, key, element[key]);
      }
      console.log('- - -');
    });
    // конец
    db.end();
  });
}

function findRecord_1(login, password) {
  db.connect();
  // 
  var myQuery = "select * from users where users.email = '" + login + "' and users.password = '" + password + "';";
  // 
  db.query(myQuery, (err, data) => {
    if (err) throw new Error(err);
    // console.log(data, err);
    // console.log(data.rowCount, err);
    // console.log(data.rows.length, err);
    // db.end(); // совсем закрывает соединение
    if(!data) console.log('В базе нет данных', data);
    else {
      console.log(data.rows.length);
      if(data.rows.length > 1) console.log('Проверка, уточнение данных. Предложение смены пароля как не безопасного, к примеру.');
      else {
        console.log('Проверка роли → переход к нужной странице');
        window.frames.myFrame1.location = "../index_files/view/10_my_travel.html";
      }
    }
  });

  // db.query('SELECT $1::text as message', ['Hello world!'], (err, res) => {
  // db.query(myQuery, (err, res) => {
  //   console.log(err ? err.stack : res.rows.length); // Hello World!
  //   db.end();
  // })
}