// main.js
// 
$(document).ready(function () {
  // когда главное окно сформировало контент и фрейм стал доступен
  window.frames.myFrame1.onload = function() {
    // отправка сообщения фрейму
    sendMessage("I am waiting!", "READY", window.frames.myFrame1);
  }
});

