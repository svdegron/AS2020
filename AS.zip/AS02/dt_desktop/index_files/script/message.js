// message.js
// 
// для справки
// console.log("main\n", window.location);
// 
var myOrigin = window.location.origin; // политика одного источника / безопасность передачи сообщений
// список окон
var myWindows = {
  "AUTHORIZATION": null
};
// прием сообщений
window.addEventListener("message", function(event) {
  if (event.origin != myOrigin) {
    console.log('Что-то пришло с неизвестного домена. Игнорируем');
    return;
  }
  receiveMessage(event);
  // event.source.postMessage("data2", "*");
});
// отправка сообщений фреймам
function sendMessage(message, type, target) {
  var id1         = Math.random();
  var typeObject1 = type || "EMPTY";
  var text1       = message || "Пустое сообщение";
  // var target1     = target1 || "ALL";
  var myMail1     = {
    typeObject: typeObject1,
    id        : id1,
    message   : text1,
    source    : "MAIN",
    created   : new Date()
  };
  // 
  target.postMessage(JSON.stringify(myMail1), myOrigin);
}
//
function receiveMessage(message) {
  // преобразуем
  var jsonObject1 = myStringParse(message.data);
  // проверяем
  if( typeof(jsonObject1) !== undefined || typeof(jsonObject1) != 'string') {
    // console.log('Сообщение для «MAIN» ' + jsonObject1.id + ":", jsonObject1.message);
    switch(jsonObject1.typeObject) {
      case 'EMPTY':
        console.log( "MAIN тип сообщения не указан: ", jsonObject1 );
        break;
      case 'READY_OK':
        // console.log("ГЛАВНОЕ окно. Сообщение от " + jsonObject1.source, jsonObject1);
        myWindows[jsonObject1.source] = event.source;
        // console.log(myWindows);
        break;
      case "ENTER_OK":
        console.log("Login: " + jsonObject1.message[0] + "\n" + "Password: " + jsonObject1.message[1]);
        var login1 = jsonObject1.message[0];
        var password1 = jsonObject1.message[1];
        findRecord_1(login1, password1);
        break;
      case "OPEN_FRAME":
        console.log("Ссылка " + jsonObject1.message);
        window.frames.myFrame1.location = "../index_files/view/" + jsonObject1.message;
        break;
      default:
        console.log( "MAIN неизвестное сообщение: ", jsonObject1 );
        break;
    }
  } else {
    // не получилось преобразовать
    console.log( "MAIN received: " + message );
  }
}