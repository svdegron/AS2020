// 01_authorization.js
// 
//для справки
// console.log("authorization\n", window.location);
// 
// политика одного источника / безопасность передачи сообщений
var myOrigin = window.location.origin;
// обработчик приема сообщений
window.addEventListener("message", function(event) {
  if (event.origin != myOrigin) {
    console.log('01_authorization.js: Что-то пришло с неизвестного домена. Игнорируем');
    return;
  }
  // передаем сообщение на обработку
  receiveMessage(event.data);
  }); /* end */
// отправка сообщений
function sendMessage(message, type, target) {
  var id1         = Math.random();
  var typeObject1 = type || "EMPTY";
  var text1       = message || "Пустое сообщение";
  var target1     =  target || "MAIN";
  // 
  var myMail1 = {
    typeObject: typeObject1,
    id        : id1,
    message   : text1,
    target    : target1,
    source    : "AUTHORIZATION",
    created   : new Date()
  };
  // 
  window.parent.postMessage(JSON.stringify(myMail1), myOrigin);
  } /* end */
// 
function receiveMessage(message) {
  // преобразуем
  var jsonObject1 = myStringParse(message);
  // проверяем
  if( typeof(jsonObject1) !== undefined || typeof(jsonObject1) != 'string') {
    // console.log('Сообщение для «01_authorization» ' + jsonObject1.id + ":", jsonObject1.message);
    switch(jsonObject1.typeObject) {
      case 'EMPTY': // пустое сообщение
        console.log( "FRAME AUTHORIZATION тип сообщения не указан: ", jsonObject1 );
        break;
      case 'READY': // готово к передаче сообщений
        sendMessage("I am ready, 01_authorization.js!", "READY_OK");
        break;
      default: // неизвестное сообщение
        console.log( "FRAME AUTHORIZATION неизвестное сообщение: ", jsonObject1 );
        break;
    }
  } else {
    // не преобразовалось
    console.log( "FRAME AUTHORIZATION received: " + message );
  }
}
// 
$(document).ready( function () {
  // // отправка сообщения главному окну о готовности
  // sendMessage("I am ready, 01_authorization.js! 11111111");
  $("#myLogin").val("email2@mail.ru");
  $("#myPassword").val("Password2");
  // 
  $("#myEnter").click( () => {
    var myLogin1 = $("#myLogin").val();
    var myPassword1 = $("#myPassword").val();
    if(myLogin1 && myPassword1) {
      // console.log(myLogin1, myPassword1);
      sendMessage([myLogin1, myPassword1], "ENTER_OK");
    }
    else console.log('Empty');
  });
  // 
  $("#myRegistration").click( () => {
    // window.open("02_registration.html");
    sendMessage("02_registration.html", "OPEN_FRAME");
  });
  // 
});
