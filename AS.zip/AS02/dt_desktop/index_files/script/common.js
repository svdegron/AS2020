// common.js - общие для всех
// 
// преобразование данных (в основном даты к датам, но может и картинки всплывут)
function myParseValue(key, value) {
  if (key == 'create') return new Date(value);
  // if (key == 'dateTime'){ return new Date(value); }
  // if (key == 'dateBegin'){ return new Date(value); } 
  // if (key == 'dateEnd'){ return new Date(value); } 
  // if (key == 'myDate'){ return new Date(value); } 
  // if (key == 'begin') return new Date(value);
  // if (key == 'myImage'){ return value && value.type === 'Buffer' ? Buffer.from(value.data) : value; }
  return value;
  } /*end*/
// 
function myStringParse(myString) {
  try { 
    // пытаемся преобразовать в json-объект
    myString = JSON.parse(myString, myParseValue);
  } catch (error1) {
    console.log("ОШИБКА! преобразования строки в json-объект\n", error1);
    // если нет, то и не надо
    return undefined;
  }
  // на всякий «пожарный»… ОШИБКА!
  return myString;
  } /*end*/